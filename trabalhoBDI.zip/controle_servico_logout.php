<?php

    require_once '../../CONEXAO/logout.php'; 

?>