<?php

    require_once '../../CONEXAO/controle_servico_receita.php'; //torna minha aplicação input privada

?>