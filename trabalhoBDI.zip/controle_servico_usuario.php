<?php
    require_once '../../CONEXAO/controle_servico_usuario.php'; //torna minha aplicação input privada

?>